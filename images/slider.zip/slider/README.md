# Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/ruben-vardanyan/pen/abqBGeo](https://codepen.io/ruben-vardanyan/pen/abqBGeo).

*Used  Owl Carousel & Jquery 
*My First Slider 
*like & use
